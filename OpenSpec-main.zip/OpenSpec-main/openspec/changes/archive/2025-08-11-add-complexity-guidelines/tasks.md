# Implementation Tasks

## 1. Update OpenSpec README
- [x] 1.1 Add "Start Simple" section after Core Principle
- [x] 1.2 Add complexity triggers to "When to Create Change Proposals" section
- [x] 1.3 Update AI workflow guidance to emphasize minimal implementations

## 2. Update CLAUDE.md
- [x] 2.1 Add complexity management rules to project instructions