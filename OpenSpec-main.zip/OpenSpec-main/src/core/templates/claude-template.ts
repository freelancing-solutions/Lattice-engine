export { agentsRootStubTemplate as claudeTemplate } from './agents-root-stub.js';
