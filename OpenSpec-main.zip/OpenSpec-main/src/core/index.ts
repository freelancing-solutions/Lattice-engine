// Core OpenSpec logic will be implemented here
export {};