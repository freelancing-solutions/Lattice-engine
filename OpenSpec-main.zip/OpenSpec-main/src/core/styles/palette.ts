import chalk from 'chalk';

export const PALETTE = {
  white: chalk.hex('#f4f4f4'),
  lightGray: chalk.hex('#c8c8c8'),
  midGray: chalk.hex('#8a8a8a'),
  darkGray: chalk.hex('#4a4a4a')
};
